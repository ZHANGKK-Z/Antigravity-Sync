﻿param(
    [switch]$SkipPause
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"

$RepoRoot = Split-Path -Parent $PSScriptRoot
$GeminiConfigDest = Join-Path $env:USERPROFILE ".gemini\config"
$PatchCacheDir = Join-Path $env:APPDATA "AntigravityChinesePatch"

Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "   Antigravity 深度中文汉化 + 类GPT中文汇报 + 工程规范一键安装" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan

# [1/3] 部署全局中文规则与通用工程插件
Write-Host "`n[1/3] 正在配置全链路中文规则与工程规范插件..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path $GeminiConfigDest -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $GeminiConfigDest "rules") -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $GeminiConfigDest "plugins") -Force | Out-Null

Copy-Item -Path (Join-Path $RepoRoot "gemini-config\GEMINI.md") -Destination (Join-Path $GeminiConfigDest "GEMINI.md") -Force
Copy-Item -Path (Join-Path $RepoRoot "gemini-config\rules\*") -Destination (Join-Path $GeminiConfigDest "rules") -Recurse -Force
Copy-Item -Path (Join-Path $RepoRoot "gemini-config\plugins\*") -Destination (Join-Path $GeminiConfigDest "plugins") -Recurse -Force
Write-Host "  -> 中文规则与插件安装完成：$GeminiConfigDest" -ForegroundColor Green

# [2/3] 智能合并 config.json（保留当前电脑自身登录态与标识，启用 Turbo 高效预设）
Write-Host "`n[2/3] 正在智能合并高效执行预设 (config.json)..." -ForegroundColor Yellow
$BaseCfgPath = Join-Path $RepoRoot "gemini-config\config.base.json"
$DestCfgPath = Join-Path $GeminiConfigDest "config.json"
$BaseObj = Get-Content -Path $BaseCfgPath -Raw -Encoding UTF8 | ConvertFrom-Json

if (Test-Path $DestCfgPath) {
    Copy-Item -Path $DestCfgPath -Destination "$DestCfgPath.bak" -Force
    try {
        $CurrentRaw = Get-Content -Path $DestCfgPath -Raw -Encoding UTF8
        $DestObj = if ($CurrentRaw -and $CurrentRaw.Trim().Length -gt 0) { $CurrentRaw | ConvertFrom-Json } else { [PSCustomObject]@{} }
    } catch {
        $DestObj = [PSCustomObject]@{}
    }
} else {
    $DestObj = [PSCustomObject]@{}
}

if (-not $DestObj.PSObject.Properties["plugins"]) {
    $DestObj | Add-Member -NotePropertyName "plugins" -NotePropertyValue ([PSCustomObject]@{}) -Force
}
foreach ($prop in $BaseObj.plugins.PSObject.Properties) {
    $DestObj.plugins | Add-Member -NotePropertyName $prop.Name -NotePropertyValue $prop.Value -Force
}

if (-not $DestObj.PSObject.Properties["userSettings"]) {
    $DestObj | Add-Member -NotePropertyName "userSettings" -NotePropertyValue ([PSCustomObject]@{}) -Force
}
foreach ($prop in $BaseObj.userSettings.PSObject.Properties) {
    $DestObj.userSettings | Add-Member -NotePropertyName $prop.Name -NotePropertyValue $prop.Value -Force
}

$MergedJson = $DestObj | ConvertTo-Json -Depth 15
[System.IO.File]::WriteAllText($DestCfgPath, $MergedJson, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "  -> 权限预设合并完成（原配置已备份为 config.json.bak）" -ForegroundColor Green

# [3/3] 注入客户端深度全量汉化 + 自动更新守护
Write-Host "`n[3/3] 正在注入 Antigravity 深度全量中文补丁与更新自愈守护..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path $PatchCacheDir -Force | Out-Null
$SrcPreload = Join-Path $RepoRoot "zh-patch\preload_patch.js"
$SrcWatcher = Join-Path $RepoRoot "zh-patch\watcher.ps1"
Copy-Item -Path $SrcPreload -Destination (Join-Path $PatchCacheDir "preload.js") -Force
Copy-Item -Path $SrcWatcher -Destination (Join-Path $PatchCacheDir "watcher.ps1") -Force

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $SrcWatcher -ForcePatch
$PatchExit = $LASTEXITCODE
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $SrcWatcher -DaemonOn | Out-Null

if ($PatchExit -eq 0) {
    Write-Host "  -> 客户端深度全量汉化与自动更新守护启用成功！" -ForegroundColor Green
} else {
    Write-Host "  -> 未在默认路径找到 Antigravity 客户端，启动一次客户端后后台守护将自动接管。" -ForegroundColor Yellow
}

Write-Host "`n======================================================" -ForegroundColor Cyan
Write-Host " 全部安装完成！请完全退出并重新打开 Antigravity 客户端即可生效。" -ForegroundColor Green
Write-Host "======================================================" -ForegroundColor Cyan

if (-not $SkipPause) {
    Write-Host "`n按任意键关闭窗口..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
