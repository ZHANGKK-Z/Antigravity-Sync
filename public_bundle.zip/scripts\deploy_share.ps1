﻿param(
    [switch]$SkipPause
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"

$RepoRoot = Split-Path -Parent $PSScriptRoot
$GeminiConfigDest = Join-Path $env:USERPROFILE ".gemini\config"
$PatchCacheDir = Join-Path $env:APPDATA "AntigravityChinesePatch"

Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "   Antigravity 深度中文汉化 + 类GPT中文汇报 + 工程规范一键安装" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan

# [1/3] 部署全局中文规则与通用工程插件
Write-Host "`n[1/3] 正在配置全链路中文规则与工程规范插件..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path $GeminiConfigDest -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $GeminiConfigDest "rules") -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $GeminiConfigDest "plugins") -Force | Out-Null

Copy-Item -Path (Join-Path $RepoRoot "gemini-config\GEMINI.md") -Destination (Join-Path $GeminiConfigDest "GEMINI.md") -Force
Copy-Item -Path (Join-Path $RepoRoot "gemini-config\rules\*") -Destination (Join-Path $GeminiConfigDest "rules") -Recurse -Force
Copy-Item -Path (Join-Path $RepoRoot "gemini-config\plugins\*") -Destination (Join-Path $GeminiConfigDest "plugins") -Recurse -Force
Write-Host "  -> 中文规则与插件安装完成：$GeminiConfigDest" -ForegroundColor Green

# [2/3] 智能合并 config.json（保留当前电脑自身登录态与标识，启用 Turbo 高效预设）
Write-Host "`n[2/3] 正在智能合并高效执行预设 (config.json)..." -ForegroundColor Yellow
$BaseCfgPath = Join-Path $RepoRoot "gemini-config\config.base.json"
$DestCfgPath = Join-Path $GeminiConfigDest "config.json"
$BaseObj = Get-Content -Path $BaseCfgPath -Raw -Encoding UTF8 | ConvertFrom-Json

if (Test-Path $DestCfgPath) {
    Copy-Item -Path $DestCfgPath -Destination "$DestCfgPath.bak" -Force
    try {
        $CurrentRaw = Get-Content -Path $DestCfgPath -Raw -Encoding UTF8
        $DestObj = if ($CurrentRaw -and $CurrentRaw.Trim().Length -gt 0) { $CurrentRaw | ConvertFrom-Json } else { [PSCustomObject]@{} }
    } catch {
        $DestObj = [PSCustomObject]@{}
    }
} else {
    $DestObj = [PSCustomObject]@{}
}

if (-not $DestObj.PSObject.Properties["plugins"]) {
    $DestObj | Add-Member -NotePropertyName "plugins" -NotePropertyValue ([PSCustomObject]@{}) -Force
}
foreach ($prop in $BaseObj.plugins.PSObject.Properties) {
    $DestObj.plugins | Add-Member -NotePropertyName $prop.Name -NotePropertyValue $prop.Value -Force
}

if (-not $DestObj.PSObject.Properties["userSettings"]) {
    $DestObj | Add-Member -NotePropertyName "userSettings" -NotePropertyValue ([PSCustomObject]@{}) -Force
}
foreach ($prop in $BaseObj.userSettings.PSObject.Properties) {
    $DestObj.userSettings | Add-Member -NotePropertyName $prop.Name -NotePropertyValue $prop.Value -Force
}

$MergedJson = $DestObj | ConvertTo-Json -Depth 15
[System.IO.File]::WriteAllText($DestCfgPath, $MergedJson, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "  -> 权限预设合并完成（原配置已备份为 config.json.bak）" -ForegroundColor Green

# [3/3] 注入客户端深度全量汉化 + 自动更新守护
Write-Host "`n[3/3] 正在注入 Antigravity 深度全量中文补丁与更新自愈守护..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path $PatchCacheDir -Force | Out-Null
$SrcPreload = Join-Path $RepoRoot "zh-patch\preload_patch.js"
$SrcWatcher = Join-Path $RepoRoot "zh-patch\watcher.ps1"
Copy-Item -Path $SrcPreload -Destination (Join-Path $PatchCacheDir "preload.js") -Force
Copy-Item -Path $SrcWatcher -Destination (Join-Path $PatchCacheDir "watcher.ps1") -Force

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $SrcWatcher -ForcePatch
$PatchExit = $LASTEXITCODE
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $SrcWatcher -DaemonOn | Out-Null

if ($PatchExit -eq 0) {
    Write-Host "  -> 客户端深度全量汉化与自动更新守护启用成功！" -ForegroundColor Green
} else {
    Write-Host "  -> 未在默认路径找到 Antigravity 客户端，启动一次客户端后后台守护将自动接管。" -ForegroundColor Yellow
}

# === BEGIN EXTRA PLUGINS (AGY-FAST + OBSIDIAN-PRISM) ===

# 辅助：定位 Antigravity.exe 路径
function Find-AgyExe {
    $candidates = @(
        "$env:LOCALAPPDATA\Programs\antigravity\Antigravity.exe",
        "$env:ProgramFiles\Antigravity\Antigravity.exe",
        "${env:ProgramFiles(x86)}\Antigravity\Antigravity.exe"
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { return $c }
    }
    $proc = Get-Process -Name "Antigravity" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($proc -and $proc.Path -and (Test-Path $proc.Path)) { return $proc.Path }
    return $null
}

# 辅助：检测系统 Node.js >= 20；若无则自动编译原生控制台桥接器复用 Antigravity 内置 Node (v24+)
$AgyExePath = Find-AgyExe
$SysNodeCmd = Get-Command node -ErrorAction SilentlyContinue
$HasModernSysNode = $false
if ($SysNodeCmd) {
    try {
        $verStr = (& node -v 2>$null)
        if ($verStr -match '^v(\d+)\.' -and [int]$Matches[1] -ge 20) {
            $HasModernSysNode = $true
        }
    } catch {}
}

if (-not $HasModernSysNode -and $AgyExePath) {
    Write-Host "  -> 当前电脑未检测到 Node.js >= 20，正在生成客户端内置 Node 桥接器以驱动 agy-fast..." -ForegroundColor Cyan
    $FastPluginDir = Join-Path $GeminiConfigDest "plugins\agy-fast"
    $ShimExe = Join-Path $FastPluginDir "agy-node-shim.exe"
    $EscapedAgyExe = $AgyExePath.Replace('\', '\\').Replace('"', '\"')
    $ShimCs = @"
using System;
using System.Diagnostics;
using System.Text;
public class AgyNodeShim {
    public static int Main(string[] args) {
        var psi = new ProcessStartInfo("$EscapedAgyExe");
        psi.UseShellExecute = false;
        psi.EnvironmentVariables["ELECTRON_RUN_AS_NODE"] = "1";
        var sb = new StringBuilder();
        for (int i = 0; i < args.Length; i++) {
            if (i > 0) sb.Append(' ');
            string a = args[i];
            if (a.Length == 0 || a.IndexOfAny(new char[] { ' ', '\t', '"' }) >= 0) {
                sb.Append('"').Append(a.Replace("\\", "\\\\").Replace("\"", "\\\"")).Append('"');
            } else {
                sb.Append(a);
            }
        }
        psi.Arguments = sb.ToString();
        using (var p = Process.Start(psi)) {
            p.WaitForExit();
            return p.ExitCode;
        }
    }
}
"@
    Add-Type -TypeDefinition $ShimCs -OutputAssembly $ShimExe -OutputType ConsoleApplication
    $McpJsonPath = Join-Path $FastPluginDir "mcp_config.json"
    if (Test-Path $McpJsonPath) {
        $McpObj = Get-Content $McpJsonPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $McpObj.mcpServers.fast.command = '${PLUGIN_ROOT}/agy-node-shim.exe'
        [System.IO.File]::WriteAllText($McpJsonPath, ($McpObj | ConvertTo-Json -Depth 10), (New-Object System.Text.UTF8Encoding($false)))
    }
}

# 若当前电脑有 winget 且未装 ripgrep (rg)，尝试静默补装以提速代码搜索（失败不阻断主流程）
if (-not (Get-Command rg -ErrorAction SilentlyContinue) -and (Get-Command winget -ErrorAction SilentlyContinue)) {
    try {
        Write-Host "  -> 正在通过 winget 补装 ripgrep (rg) 极速搜索内核..." -ForegroundColor Gray
        & winget install -e --id BurntSushi.ripgrep.MSVC --silent --accept-package-agreements --accept-source-agreements 2>$null | Out-Null
    } catch {}
}

# 部署 Obsidian Prism · 黑曜棱镜（官方原版源拉取 + 自动修补快捷方式与启动后台守护）
Write-Host "`n[+] 正在部署 Obsidian Prism (黑曜棱镜 UI 套件 + 512K 上下文试管 + 配额看板)..." -ForegroundColor Yellow
$PrismSrcDir = Join-Path $env:USERPROFILE ".gemini\obsidian-prism-src"
$PrismZip = Join-Path $env:TEMP ("prism_src_" + [Guid]::NewGuid().ToString("N") + ".zip")
$PrismExtract = Join-Path $env:TEMP ("prism_ext_" + [Guid]::NewGuid().ToString("N"))

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $ProxyUri = $null
    try {
        $ie = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
        if ($ie -and $ie.ProxyEnable -eq 1 -and $ie.ProxyServer) {
            $ps = $ie.ProxyServer
            if ($ps -notmatch '^https?://') { $ps = "http://$ps" }
            $ProxyUri = $ps
        }
    } catch {}

    $PrismUrls = @(
        "https://ghfast.top/https://github.com/RMvdesi/obsidian-prism/archive/refs/heads/main.zip",
        "https://gh-proxy.com/https://github.com/RMvdesi/obsidian-prism/archive/refs/heads/main.zip",
        "https://codeload.github.com/RMvdesi/obsidian-prism/zip/refs/heads/main"
    )

    $PrismOk = $false
    foreach ($pu in $PrismUrls) {
        try {
            if ($ProxyUri -and $pu -like "*codeload.github.com*") {
                Invoke-WebRequest -Uri $pu -OutFile $PrismZip -Proxy $ProxyUri -UseBasicParsing -TimeoutSec 25
            } else {
                Invoke-WebRequest -Uri $pu -OutFile $PrismZip -UseBasicParsing -TimeoutSec 20
            }
            if ((Test-Path $PrismZip) -and (Get-Item $PrismZip).Length -gt 100000) {
                $PrismOk = $true
                break
            }
        } catch {
            Write-Host "  -> 正在切换 Obsidian Prism 备用下载节点..." -ForegroundColor Gray
        }
    }

    if ($PrismOk) {
        Expand-Archive -Path $PrismZip -DestinationPath $PrismExtract -Force
        $SubFolder = Get-ChildItem -Path $PrismExtract -Directory | Select-Object -First 1
        if ($SubFolder) {
            if (Test-Path $PrismSrcDir) { Remove-Item -Path $PrismSrcDir -Recurse -Force -ErrorAction SilentlyContinue }
            Move-Item -Path $SubFolder.FullName -Destination $PrismSrcDir -Force
        }

        $InstallerCjs = Join-Path $PrismSrcDir "tools\install-plugin.cjs"
        if (Test-Path $InstallerCjs) {
            $HasNode22 = $false
            if ($SysNodeCmd) {
                try {
                    $v22 = (& node -v 2>$null)
                    if ($v22 -match '^v(\d+)\.' -and [int]$Matches[1] -ge 22) { $HasNode22 = $true }
                } catch {}
            }
            if ($HasNode22) {
                & node $InstallerCjs --install | Out-Null
            } elseif ($AgyExePath) {
                $prevEnv = $env:ELECTRON_RUN_AS_NODE
                $env:ELECTRON_RUN_AS_NODE = "1"
                try {
                    Start-Process -FilePath $AgyExePath -ArgumentList "`"$InstallerCjs`" --install" -Wait -NoNewWindow | Out-Null
                } finally {
                    if ($null -eq $prevEnv) { Remove-Item Env:\ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue } else { $env:ELECTRON_RUN_AS_NODE = $prevEnv }
                }
            }
            Write-Host "  -> Obsidian Prism 部署、快捷方式修补与后台守护启动成功！" -ForegroundColor Green
        }
    } else {
        Write-Host "  -> [提示] Obsidian Prism 在线拉取超时，其余配置与汉化均已完成。" -ForegroundColor Yellow
    }
} finally {
    Remove-Item -Path $PrismZip -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $PrismExtract -Recurse -Force -ErrorAction SilentlyContinue
}

# === END EXTRA PLUGINS ===

Write-Host "`n======================================================" -ForegroundColor Cyan
Write-Host " 全部安装完成！请彻底退出并通过桌面快捷方式重新打开 Antigravity 即可激活全部汉化、加速与黑曜棱镜界面！" -ForegroundColor Green
Write-Host "======================================================" -ForegroundColor Cyan

if (-not $SkipPause) {
    Write-Host "`n按任意键关闭窗口..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
