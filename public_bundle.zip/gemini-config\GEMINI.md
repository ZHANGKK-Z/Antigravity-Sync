# Always Search the Web Before Answering

- **Mandatory Web Search**: For every user request, question, or task, you MUST ALWAYS perform a web search using `search_web` (or `read_url_content` if a URL is provided) before formulating your final response.
- **Fresh & Verified Information**: Retrieve up-to-date, authoritative, and accurate information from current web sources.
- **Reference & Citations**: Clearly synthesize the search findings and provide relevant references in your response.
